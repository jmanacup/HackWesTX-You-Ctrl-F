counter = 1;
    document.querySelector('button').addEventListener('click', onclick, false)
        function onclick (e){
            console.log(e);
            chrome.tabs.query({currentWindow: true, active: true},
                function(tabs){

                    chrome.tabs.sendMessage(tabs[0].id,'You pushed the button');

                    //This is for the video id
                    var url = tabs[0].url.split("v=")[1].substring(0, 11);
                    //this is for the word to be searched
                    var word = document.getElementById('word').value;

                    let entirePath = "https://www.youtube.com/api/timedtext?lang=en&v=" + String(url);

                    //to download the xml file
                /*
                    chrome.downloads.download({
                        url: String(entirePath),
                        filename: String(word) + counter + ".xml",
                      });

                      counter++;
*/

                    var requestOptions = {
                        method: 'GET',
                        redirect: 'follow'
                    };
                    
                    fetch(entirePath)
                        .then(response => chrome.tabs.sendMessage(tabs[0].id,response.text()))
                        .then(result => console.log(result))
                        
            });
        }   
  
        
    
